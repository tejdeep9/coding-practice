struct Node{
	int data;
	Node* left;
	Node* right;
};

Node* getNewNode(int data)
{
	Node* newNode= new Node;
	newNode->data=data;
	newNode->left=NULL;
	newNode->right =NULL;
}

Node* insert(Node* root, int data)
{
	if(root == NULL)
	{
		root= getNewNode(data);
		return root;
	}
	if(data > root->data)
	{
		root->right=insert(root->right, data);
	}
	else
	{
		root->left=insert(root->left, data);
	}
	
	return root;
}

//Delete the node from the root
Node* Delete(Node* root, int data)
{
	if(root == NULL)
		return root;
	if( root->data > data) root->right=Delete(root->right, data);
	else if(root->data < data) root->left=Delete(root->left, data);
	else //if the node is found
	{
		if( root->left!= NULL && root->right==NULL) //if the node is leaf node
		{
			delete root;
			root=NULL:
		}
		else if( root->left== NULL) //if the node has one child
		{
			Node* temp=root->right;
			root=root->right;
			delete temp;
		}
		else if(root->right ==NULL)
		{
			Node* temp=root->left;
			root=root->left;
			delete temp;;
			
		}
		else //if the node has two children
		{
			Node* temp= FinMin(root->right);
			root->data= temp->data;
			root->right=Delete(root->right, temp->data);
		}
	}
	return root;

}
bool search(Node* root, int data)
{
	if(root == NULL)
		return false;
	if( root->data == data)
		retrun true;
	else if( data > root->data)
		return search?(root->right, data);
	else
		return search(root->left,data);
}

int FindMin(Node* root)
{
	Node* current =root;
	while(current->left!=NULL)
	{
		current=current->left;
	}
	return current->data;
}

int FindMin(Node* root)
{
	Node* current =root;
	while(current->right!=NULL)
	{
		current=current->right;
	}
	return current->data;
}


int Height(Node* root)
{
	if(root == NULL)
		return -1;
	return max(Height(root->left), Height(root->right)+1;
}

bool isBstUtil(Node* root, int min, int max)
{
	if(root == NULL)
		return true;
	if( (root->data < max) && (root->data >= min) 
	    && isBstUtil(root->left, min, root->data)
		&& isBstUtil(root->right, root->data, max))
		return ture;
	else
		return false;
}